<?php

/*
 * عينة صفحة الطلب الخاص (بتصميم المدير): البيانات من نفس APIs صفحة الطلب الخاص في جوماكيك.
 */

return [

    // عدد صور الذكاء الاصطناعي لكل زائر (الصور اللي طلعت فعلًا)، ويتجدد مع "إرسال للمراجعة".
    // 0 = بدون حد (وقت التجربة). يتغيّر من .env بدون تعديل الكود: SPECIAL_ORDER_AI_LIMIT=5
    // بعد الربط بنظام الطلبات: لكل رقم جوال، ويتجدد لما ينطلب الطلب
    'ai_limit' => (int) env('SPECIAL_ORDER_AI_LIMIT', 5),

    // جودة صور الذكاء الاصطناعي في الكعكة الخاصة (low / medium / high)، وإذا فاضي تاخذ OPENAI_IMAGE_QUALITY
    'image_quality' => env('SPECIAL_ORDER_IMAGE_QUALITY'),

    // عدد رسائل المحادثة مع الذكاء الاصطناعي لكل زائر (0 = بدون حد). الصور المعدّلة تنحسب من ai_limit
    'chat_limit' => (int) env('SPECIAL_ORDER_CHAT_LIMIT', 30),

    'cache_minutes' => 60,

    // عدد الأشخاص لكيكات الأدوار (الـ API يعطي المقاسات المفردة فقط)
    'tier_people' => [
        'tier2_6-4' => '6',
        'tier2_8-6' => '14',
        'tier2_10-8' => '23',
        'tier3_8-6-4' => '15',
        'tier3_10-8-6' => '28',
    ],

    // نسخة احتياطية (أكتوبر 2026) إذا موقع جوماكيك ما رد.
    // النكهات والحشوات المعروضة = اللي لها سعر في cakes-pricing، والزيادة حسب المقاس بالإنش.
    'fallback' => [
        'sizes' => [
            '4' => ['id' => 2, 'people' => '1-2'],
            '6' => ['id' => 4, 'people' => '4-6'],
            '8' => ['id' => 9, 'people' => '8-10'],
            '10' => ['id' => 10, 'people' => '12-15'],
        ],
        'flavors' => [
            ['id' => 311, 'name' => 'فانيلا', 'title_en' => 'Vanilla', 'image' => null, 'extra' => ['4' => 0, '6' => 0, '8' => 0, '10' => 0]],
            ['id' => 314, 'name' => 'شوكولاته', 'title_en' => 'Chocolate', 'image' => null, 'extra' => ['4' => 0, '6' => 0, '8' => 0, '10' => 0]],
        ],
        'fillings' => [
            ['id' => 44, 'name' => 'ويب كريم ساده', 'title_en' => 'Plain whipped cream', 'image' => null, 'extra' => ['4' => 0, '6' => 0, '8' => 0, '10' => 0]],
            ['id' => 325, 'name' => 'ويب كريم ساده (وردي)', 'title_en' => 'Plain whipped cream (pink)', 'image' => null, 'extra' => ['4' => 0, '6' => 0, '8' => 0, '10' => 0]],
            ['id' => 326, 'name' => 'ويب كريم ساده (ازرق)', 'title_en' => 'Plain whipped cream (blue)', 'image' => null, 'extra' => ['4' => 0, '6' => 0, '8' => 0, '10' => 0]],
            ['id' => 312, 'name' => 'ويب كريم مع نوتيلا', 'title_en' => 'Whipped cream with Nutella', 'image' => null, 'extra' => ['4' => 10, '6' => 10, '8' => 15, '10' => 15]],
            ['id' => 313, 'name' => 'ويب كريم مع زبدة الفستق', 'title_en' => 'Whipped cream with pistachio butter', 'image' => null, 'extra' => ['4' => 10, '6' => 10, '8' => 15, '10' => 15]],
            ['id' => 322, 'name' => 'ويب كريم مع فراوله', 'title_en' => 'Whipped cream with strawberry', 'image' => null, 'extra' => ['4' => 10, '6' => 10, '8' => 15, '10' => 15]],
        ],
    ],

];

<?php

namespace App\Http\Controllers;

use App\Services\AiCakeChat;
use App\Services\ShopProducts;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

/**
 * تعديل صورة منتج جوماكيك بالذكاء الاصطناعي: نفس الكيكة، والزبون يكتب وش يبي يغيّر
 * (لون، كتابة، إضافة…) ويقدر يرفع صور للي يبيه. مستقل عن الطلب الخاص (عداده وإعداداته لحاله).
 * نفس طريقة الطلب الخاص: رقم لكل توليد (job) والصفحة تسأل عن نتيجته إذا انقطع الطلب.
 */
class ShopAiController extends Controller
{
    private const DIR = 'ai-cakes';
    private const MAX_REFERENCES = 6;

    // الشكل المطلوب من فوق، والأشكال اللي لازم ما يطلع عليها (لو صورة المنتج شكلها مختلف)
    private const OUTLINES = [
        'round' => ['perfectly ROUND (a circle when seen from above)', 'NOT heart-shaped, NOT square, NOT oval'],
        'heart' => ['HEART-shaped when seen from above', 'NOT round, NOT square'],
        'star' => ['a FIVE-POINTED STAR when seen from above', 'NOT round, NOT heart-shaped'],
        'dome' => ['a smooth DOME (half-sphere), round when seen from above', 'NOT a flat-topped cylinder, NOT heart-shaped, with NO ears'],
        'cone' => ['a tall CONE tapering to a point', 'NOT a cylinder, NOT round-topped'],
        'sunset' => ['a HALF-CIRCLE standing upright on its flat edge', 'NOT a full round cake, NOT heart-shaped'],
    ];

    public function generate(Request $request, int $id, ShopProducts $shop)
    {
        $product = $shop->find($id);
        abort_unless($product, 404);

        $data = $request->validate([
            'shape' => ['required', 'in:'.implode(',', array_keys(self::OUTLINES))],
            'note' => ['nullable', 'string', 'max:500'],
            'writing' => ['nullable', 'string', 'max:40'],
            'shape_image' => ['nullable', 'image', 'mimes:png,jpg,jpeg,webp', 'max:5120'],
            'size' => ['required', 'integer'],
            'layers' => ['required', 'integer', 'between:1,4'],
            'references' => ['nullable', 'array', 'max:'.self::MAX_REFERENCES],
            'references.*' => ['image', 'mimes:png,jpg,jpeg,webp', 'max:10240'],
            'job' => ['required', 'string', 'regex:/^[A-Za-z0-9-]{8,64}$/'],
        ], [
            'note.max' => 'الوصف طويل، الحد 500 حرف.',
            'references.max' => 'الحد '.self::MAX_REFERENCES.' صور.',
        ]);

        $size = collect($product['sizes'])->firstWhere('id', (int) $data['size']);
        if (! $size) {
            return response()->json(['message' => 'المقاس غير متاح لهذا المنتج.'], 422);
        }

        if ($this->remaining() === 0) {
            return response()->json(['message' => 'استخدمتِ كل محاولات التوليد ('.config('shop.ai_limit').').', 'remaining' => 0], 429);
        }

        if (blank(config('services.openai.key'))) {
            return response()->json(['message' => 'لا يوجد مفتاح OpenAI. أضيفي OPENAI_API_KEY في ملف .env ثم شغّلي php artisan config:clear'], 503);
        }

        $job = $data['job'];
        Cache::put($this->jobKey($job), ['status' => 'working', 'owner' => $this->visitor()], now()->addMinutes(15));
        ignore_user_abort(true);
        set_time_limit(330);

        try {
            // صورة المنتج من رابطه في رد المتجر (مو من الزبون)
            $photo = Http::timeout(20)->get($product['image'])->throw();
            $pending = Http::withToken(config('services.openai.key'))->acceptJson()->timeout(300)
                ->attach('image[]', $photo->body(), 'product.jpg', ['Content-Type' => $photo->header('Content-Type') ?: 'image/jpeg']);

            // الترتيب: صورة المنتج (التصميم)، صورة المجسم (الشكل والمقاس)، صور الزبون (التعديل)
            foreach (array_filter([$request->file('shape_image'), ...$request->file('references', [])]) as $file) {
                $pending->attach('image[]', file_get_contents($file->getRealPath()), $file->getClientOriginalName(), ['Content-Type' => $file->getMimeType()]);
            }

            $response = $pending->post('https://api.openai.com/v1/images/edits', [
                'model' => config('services.openai.image_model'),
                'prompt' => $this->prompt($data, $size, (bool) $request->file('shape_image'), (bool) $request->file('references')),
                'size' => '1024x1024',
                'quality' => config('shop.image_quality') ?: config('services.openai.image_quality'),
                'n' => 1,
            ]);
        } catch (ConnectionException) {
            return $this->finish($request, $job, 422, ['message' => 'تعذر الوصول إلى OpenAI. جربي مرة ثانية.']);
        } catch (\Illuminate\Http\Client\RequestException) {
            return $this->finish($request, $job, 422, ['message' => 'تعذر تحميل صورة المنتج من جوماكيك. جربي بعد شوي.']);
        }

        if ($response->failed()) {
            $code = $response->json('error.code');
            $message = (string) $response->json('error.message');
            // السبب الحقيقي في السجل (مثلًا شخصيات محمية بحقوق مثل سبايدر مان)
            Log::warning('shop AI image refused', ['product' => $product['id'], 'code' => $code, 'message' => $message]);

            return $this->finish($request, $job, 422, ['message' => $code === 'moderation_blocked' || str_contains(strtolower($message), 'safety')
                ? 'الذكاء الاصطناعي رفض هذي الصورة، غالبًا لأن فيها شخصية مشهورة محمية بحقوق (مثل سبايدر مان). جربي كيكة ثانية أو اكتبي تعديل بدون الشخصية.'
                : "خطأ من OpenAI ({$response->status()}): {$message}"]);
        }

        $image = $response->json('data.0.b64_json');
        if (! $image) {
            return $this->finish($request, $job, 422, ['message' => 'ما رجعت صورة من الذكاء الاصطناعي. جربي مرة ثانية.']);
        }

        Cache::increment($this->usedKey());
        $path = self::DIR.'/'.now()->format('Ymd-His').'-'.Str::random(6)."-product-{$product['id']}.png";
        Storage::disk('public')->put($path, base64_decode($image));
        $this->rememberImage($path);

        return $this->finish($request, $job, 200, ['image' => asset('storage/'.$path)]);
    }

    /**
     * المحادثة بعد أول صورة (نفس الكعكة الخاصة): يرد ويسأل، أو يحوّل الطلب لتعديل
     */
    public function chat(Request $request, int $id, ShopProducts $shop)
    {
        [$product, $size, $data] = $this->specs($request, $id, $shop, [
            'messages' => ['required', 'array', 'min:1', 'max:20'],
            'messages.*.role' => ['required', 'in:user,assistant'],
            'messages.*.content' => ['required', 'string', 'max:500'],
        ]);

        if (blank(config('services.openai.key'))) {
            return response()->json(['message' => 'لا يوجد مفتاح OpenAI. أضيفي OPENAI_API_KEY في ملف .env ثم شغّلي php artisan config:clear'], 503);
        }

        $limit = (int) config('shop.chat_limit');
        if ($limit > 0 && (int) Cache::get($this->chatKey(), 0) >= $limit) {
            return response()->json(['message' => "وصلتِ لحد الرسائل ({$limit}). كمّلي الطلب بالتصميم اللي اخترتيه."], 429);
        }

        [$outline] = self::OUTLINES[$data['shape']];
        try {
            $answer = app(AiCakeChat::class)->reply(
                "shape {$outline}; exactly ONE tier; size {$size['inch']} inches; {$data['layers']} sponge layers; a square JOMACAKE board with its logo label. The design comes from a JOMACAKE shop product.",
                $data['messages'],
            );
        } catch (ConnectionException) {
            return response()->json(['message' => 'تعذر الوصول إلى OpenAI. جربي مرة ثانية.'], 422);
        }

        if (! $answer) {
            return response()->json(['message' => 'ما قدر الذكاء الاصطناعي يرد الحين. جربي مرة ثانية.'], 422);
        }

        Cache::increment($this->chatKey());

        return response()->json($answer);
    }

    /**
     * تعديل على صورة طلعت قبل لنفس الزائر، مع الالتزام بالشكل والمقاس
     */
    public function edit(Request $request, int $id, ShopProducts $shop)
    {
        [$product, $size, $data] = $this->specs($request, $id, $shop, [
            'image' => ['required', 'string', 'regex:/^[A-Za-z0-9-]+-product-\d+\.png$/'],
            'instruction' => ['required', 'string', 'max:1000'],
'references' => ['nullable', 'array', 'max:6'],
            'references.*' => ['image', 'mimes:png,jpg,jpeg,webp', 'max:10240'],
            'previous' => ['nullable', 'array', 'max:12'],
            'previous.*' => ['string', 'max:1000'],
            'job' => ['required', 'string', 'regex:/^[A-Za-z0-9-]{8,64}$/'],
        ]);

        $path = self::DIR.'/'.$data['image'];
        if (! in_array($path, Cache::get($this->imagesKey(), []), true) || ! Storage::disk('public')->exists($path)) {
            return response()->json(['message' => 'الصورة مو موجودة. ولّدي صورة جديدة.'], 422);
        }

        if ($this->remaining() === 0) {
            return response()->json(['message' => 'استخدمتِ كل محاولات التوليد ('.config('shop.ai_limit').').', 'remaining' => 0], 429);
        }

        if (blank(config('services.openai.key'))) {
            return response()->json(['message' => 'لا يوجد مفتاح OpenAI. أضيفي OPENAI_API_KEY في ملف .env ثم شغّلي php artisan config:clear'], 503);
        }

        $job = $data['job'];
        Cache::put($this->jobKey($job), ['status' => 'working', 'owner' => $this->visitor()], now()->addMinutes(15));
        ignore_user_abort(true);
        set_time_limit(330);

        [$outline, $notShapes] = self::OUTLINES[$data['shape']];
        try {
            $pending = Http::withToken(config('services.openai.key'))->acceptJson()->timeout(300)
                ->attach('image[]', Storage::disk('public')->get($path), 'current.png', ['Content-Type' => 'image/png']);
            foreach ($request->file('references', []) as $file) {
                $pending->attach('image[]', file_get_contents($file->getRealPath()), $file->getClientOriginalName(), ['Content-Type' => $file->getMimeType()]);
            }
            $response = $pending->post('https://api.openai.com/v1/images/edits', [
                    'model' => config('services.openai.image_model'),
                    'prompt' => "HARD RULE (most important): the cake must stay {$outline}, with exactly ONE tier, {$notShapes}. "
                        .'This image is the customer\'s current cake design from JOMACAKE bakery. Apply ONLY these new changes: '.$data['instruction'].' '
                        .$this->keepText($data['previous'] ?? [])
                        // صور أرفقها الزبون مع رسالته للتوضيح
                        .($request->file('references') ? 'The other images are reference photos the customer attached to explain this change: take from them only what the change asks for (an element, colour or style), never their cake shape or size. ' : '')
                        .'Keep everything else exactly the same: the same cake shape, size and proportions, the same layers, '
                        .'the same square board with the JOMACAKE label, the same camera angle, lighting and background. '
                        ."Real size: {$size['inch']} inches wide. A realistic professional bakery photo of ONE cake. No people, no hands. "
                        ."Remember: {$outline}.",
                    'size' => '1024x1024',
                    'quality' => config('shop.image_quality') ?: config('services.openai.image_quality'),
                    'n' => 1,
                ]);
        } catch (ConnectionException) {
            return $this->finish($request, $job, 422, ['message' => 'تعذر الوصول إلى OpenAI. جربي مرة ثانية.']);
        }

        if ($response->failed() || ! ($image = $response->json('data.0.b64_json'))) {
            $code = $response->json('error.code');
            $message = (string) $response->json('error.message');
            Log::warning('shop AI edit failed', ['product' => $product['id'], 'code' => $code, 'message' => $message]);

            return $this->finish($request, $job, 422, ['message' => $code === 'moderation_blocked' || str_contains(strtolower($message), 'safety')
                ? 'الذكاء الاصطناعي رفض هذا التعديل، غالبًا بسبب شخصية مشهورة محمية بحقوق. جربي تعديل ثاني.'
                : 'ما طلع التعديل. جربي مرة ثانية.']);
        }

        Cache::increment($this->usedKey());
        $newPath = self::DIR.'/'.now()->format('Ymd-His').'-'.Str::random(6)."-product-{$product['id']}.png";
        Storage::disk('public')->put($newPath, base64_decode($image));
        $this->rememberImage($newPath);

        return $this->finish($request, $job, 200, ['image' => asset('storage/'.$newPath)]);
    }

    /**
     * المنتج والمقاس والمواصفات المختارة (الشكل، المقاس، الطبقات) + حقول الطلب
     */
    private function specs(Request $request, int $id, ShopProducts $shop, array $rules): array
    {
        $product = $shop->find($id);
        abort_unless($product, 404);

        $data = $request->validate([
            'shape' => ['required', 'in:'.implode(',', array_keys(self::OUTLINES))],
            'size' => ['required', 'integer'],
            'layers' => ['required', 'integer', 'between:1,4'],
        ] + $rules, [
            'messages.*.content.max' => 'الرسالة طويلة، الحد 500 حرف.',
        ]);

        $size = collect($product['sizes'])->firstWhere('id', (int) $data['size']);
        abort_unless($size, 422, 'المقاس غير متاح لهذا المنتج.');

        return [$product, $size, $data];
    }

    /**
     * التعديلات السابقة اللي طلعت منها الصورة الحالية، وقاعدة إن أي شي ما انطلب ما يتغير
     */
    private function keepText(array $previous): string
    {
        $previous = array_values(array_filter(array_map('trim', $previous)));
        $list = $previous
            ? 'This image already includes these earlier customer changes, and ALL of them must stay exactly as they are now: '
                .implode(' ', array_map(fn ($p, $i) => ($i + 1).') '.$p, $previous, array_keys($previous))).' '
            : '';

        return $list.'Do not add, remove or move anything that is not mentioned in the new changes: keep the exact NUMBER, position, '
            .'colour, size and facing direction of every element (for example the number of balloons and which way each figure faces). ';
    }

    private function chatKey(): string
    {
        return 'shop.ai_chat.'.$this->visitor();
    }

    private function imagesKey(): string
    {
        return 'shop.ai_images.'.$this->visitor();
    }

    private function rememberImage(string $path): void
    {
        Cache::put($this->imagesKey(), [...array_slice(Cache::get($this->imagesKey(), []), -19), $path], now()->addHours(12));
    }

    public function status(string $job)
    {
        $result = Cache::get($this->jobKey($job));

        if (! $result || $result['owner'] !== $this->visitor()) {
            return response()->json(['status' => 'missing', 'remaining' => $this->remaining()], 404);
        }

        return response()->json(collect($result)->except('owner')->all() + ['remaining' => $this->remaining()]);
    }

    private function prompt(array $data, array $size, bool $withShapeImage, bool $withReferences): string
    {
        $layers = (int) $data['layers'];
        $width = round((int) $size['inch'] * 2.54);
        $height = $layers * ((int) $size['inch'] <= 4 ? 3 : 4);
        [$outline, $notShapes] = self::OUTLINES[$data['shape']];
        $refIndex = $withShapeImage ? 3 : 2;

        // نفس درس الطلب الخاص: الشكل شرط أول، وإلا ينسخ شكل صورة المنتج
        return "HARD RULE (most important): the cake must be {$outline}, with exactly ONE tier, {$notShapes}, "
            .'even if image 1 shows a different shape. '
            .'Image 1 is a real cake from the JOMACAKE bakery: copy its design onto the required shape: the frosting colours, '
            .'textures and every decoration (drawings, figures, piping, fruit…), re-arranged to fit the new shape. '
            .($withShapeImage ? 'Image 2 is a grey clay mock-up of the required cake: use it ONLY for the shape, outline, proportions and height; ignore its grey colour. ' : '')
            .($withReferences ? "Images {$refIndex} and after are the customer's reference photos for the requested changes: take the elements, colours or style they ask for, but do NOT copy their cake shape. " : '')
            ."Real size: {$size['inch']} inches ({$width} cm) wide and about {$height} cm tall ({$layers} sponge layers), clearly wider than tall. "
            .(filled($data['note'] ?? null) ? "Customer changes (apply them exactly): {$data['note']}. " : 'Keep the design of image 1 as it is. ')
            .(filled($data['writing'] ?? null) ? "Write exactly this text on the cake, in the same language: \"{$data['writing']}\". " : '')
            .'Put the cake on a SQUARE flat '.((int) $size['inch'] <= 4 ? 'very light pink' : 'off-white').' cake board (NOT round), '
            .'with a small white rectangular label with "JOMACAKE" in pink serif capital letters at the front-left corner. '
            .'A realistic professional bakery photo of ONE cake, front three-quarter view, plain light background. No people, no hands. '
            ."Remember: {$outline}.";
    }

    private function finish(Request $request, string $job, int $status, array $payload)
    {
        if (defined('LARAVEL_START')) {
            Log::info('shop AI image', [
                'ok' => $status === 200,
                'seconds' => round(microtime(true) - LARAVEL_START),
                'quality' => config('shop.image_quality'),
                'references' => count($request->file('references', [])),
            ]);
        }

        Cache::put($this->jobKey($job), $payload + [
            'status' => $status === 200 ? 'done' : 'failed',
            'owner' => $this->visitor(),
        ], now()->addMinutes(15));

        return response()->json($payload + ['remaining' => $this->remaining()], $status);
    }

    private function jobKey(string $job): string
    {
        return "shop.ai_job.{$job}";
    }

    private function usedKey(): string
    {
        return 'shop.ai_used.'.$this->visitor();
    }

    private function visitor(): string
    {
        if (! session()->has('shop.visitor')) {
            session()->put('shop.visitor', (string) Str::uuid());
        }

        return session('shop.visitor');
    }

    // null = بدون حد
    public function remaining(): ?int
    {
        $limit = (int) config('shop.ai_limit');

        return $limit > 0 ? max(0, $limit - (int) Cache::get($this->usedKey(), 0)) : null;
    }
}

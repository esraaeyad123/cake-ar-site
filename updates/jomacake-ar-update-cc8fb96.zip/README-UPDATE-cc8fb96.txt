تحديث jomacake-ar: من a7368df إلى cc8fb96
=========================================

يكمّل على ملف التحديث jomacake-ar-update-a7368df.
ما تغيّر موديل الذكاء الاصطناعي (الصور gpt-image-2، المحادثة gpt-5-mini).

1. تعليمات الصور صارت قصيرة مثل ChatGPT (128 كلمة بدل 740): تركّز على صورة العميل والشكل المختار.
   - ملف جديد: app/Services/SimplePrompt.php
   - config/cake_ar.php: إعداد prompt_style. القديمة محفوظة، وترجع لها بسطر في .env:
       AI_PROMPT_STYLE=strict
   - app/Http/Controllers/SpecialOrderController.php و ShopAiController.php

2. إصلاح "اي وما يطلع شي": لما الاستضافة تقطع الطلب الطويل، الصفحة تنتظر النتيجة بدل "صار خطأ"،
   ولو صار خطأ يطلع داخل المحادثة.

3. التصميم (طلبات المدير):
   - مكان إرفاق الصور بنفس ارتفاع المجسم 3D.
   - شلنا زر "إرسال"، والإرسال من زر الكيبورد. خانة الكتابة نحيفة وزر + على اليسار جنبها.
   - عداد الصور المرفقة (مثل 5/6 صور).
   - عداد الانتظار تنازلي حسب الجودة: high = 129 ثانية، medium = 60، low = 30.
   الملفات: resources/views/special-order.blade.php و resources/views/shop/show.blade.php
            و lang/ar/cake_ar.php و lang/en/cake_ar.php

4. الجودة: نوصي بـ medium (الصورة 47 ثانية بدل دقيقتين ونص، وأرخص بكثير). في .env:
     OPENAI_IMAGE_QUALITY=medium

⚠️ لو صفحاتك فيها تعديلات خاصة فيك، قارن قبل ما تستبدل (أو استخدم ملف الـ patch).
ما فيه تغيير في routes/web.php ولا صور جديدة.

بعد النسخ:
php artisan view:clear
php artisan config:clear

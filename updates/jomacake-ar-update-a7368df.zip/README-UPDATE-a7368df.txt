تحديث jomacake-ar: من f602840 إلى a7368df
=========================================

يكمّل على ملف التحديث jomacake-ar-update-f602840 (ويشمل كل اللي في b0edd46 وزيادة).
ما تغيّر موديل الذكاء الاصطناعي: الصور gpt-image-2 والمحادثة gpt-5-mini زي ما هي. التعديل في التعليمات بس.

جزء 1 (مهم 🔴، إصلاح الذكاء الاصطناعي، ملفات PHP بس):
  app/Services/CakeStyle.php
  app/Services/AiCakeChat.php
  app/Http/Controllers/SpecialOrderController.php
  app/Http/Controllers/ShopAiController.php
  - ما عاد يكتب كلام المحادثة (المقاسات والطبقات والوصف) على الكيكة. يكتب بس لو الزبون طلب صراحة "اكتبي ...".
  - التصميم يتشكّل على الشكل المختار بدل ما ينرسم عليه: فستان + مخروط = المخروط يصير تنورة الفستان والصدر فوقه.
  هذا الجزء تقدر تنسخه لحاله حتى لو صفحاتك معدّلة.

جزء 2 (تصميم وجوال):
  resources/views/special-order.blade.php
  resources/views/shop/show.blade.php
  resources/views/shop/layout.blade.php
  lang/ar/cake_ar.php و lang/en/cake_ar.php
  - إرفاق الصور مثل تصميم المدير: مربع منقّط "أرفقي الصورة المطلوبة"، وبعد الإرفاق صور بولارويد فوق بعض وزر "إضافة صورة".
  - خلفية وردي فاتح (#FCF5F7).
  - الجوال: لما الزبون يكتب في المحادثة، الجزء العلوي ما يبقى ثابت، فتبان الخانة فوق الكيبورد.
    (لو ما تبي تستبدل الصفحة كاملة: CSS سطر body.typing .top-fixed { position: relative; }
     و focus/blur على #chat-input يضيف/يشيل class "typing" على body)
  ⚠️ لو صفحاتك فيها تعديلات خاصة فيك، قارن قبل ما تستبدل (أو استخدم ملف الـ patch).

ما فيه تغيير في routes/web.php ولا صور جديدة.

بعد النسخ:
php artisan view:clear
php artisan config:clear

<?php

namespace App\Services;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * السعر المبدئي للكعكة الخاصة (نكهة وحشوة أساسية) من أسعار موقع جوماكيك:
 * سعر المقاس + زيادة عدد الطبقات. الفنتج بنفس سعر السادة.
 */
class CakePricing
{
    /**
     * السعر المبدئي لكل مقاس/كومبو حسب الطبقات المسموحة في الصفحة:
     * ['4in' => [2 => 65, 3 => 75], 'tier2_6-4' => [2 => 110, ...], ...]
     * كيكة الأدوار = مجموع سعر كل دور بمقاسه وبنفس عدد الطبقات (مثل نظام جوماكيك): دورين 8/6 = سعر 8 + سعر 6.
     */
    public function startingPrices(): array
    {
        $table = $this->table();
        $prices = [];

        foreach (config('cake_ar.layers') as $sizeKey => $allowed) {
            $inches = self::inches($sizeKey);

            foreach ($allowed as $layers) {
                $sum = 0;
                foreach ($inches as $inch) {
                    if (! isset($table[$inch]['layers'][$layers])) {
                        continue 2; // مقاس من الأدوار ما له سعر بهالطبقات: ما نعرض سعر ناقص
                    }
                    $sum += $table[$inch]['base'] + $table[$inch]['layers'][$layers];
                }
                $prices[$sizeKey][$layers] = $sum;
            }
        }

        return $prices;
    }

    /**
     * مقاسات الأدوار بالإنش: "6in" => ['6']، "tier2_8-6" => ['8', '6']
     *
     * @return string[]
     */
    public static function inches(string $sizeKey): array
    {
        return str_starts_with($sizeKey, 'tier')
            ? explode('-', substr($sizeKey, strpos($sizeKey, '_') + 1))
            : [rtrim($sizeKey, 'in')];
    }

    /**
     * جدول الأسعار بنفس شكل الاحتياطي في config/cake_ar.php
     */
    public function table(): array
    {
        if ($cached = Cache::get('cake_ar.pricing')) {
            return $cached;
        }

        try {
            $table = $this->fetch();
            $minutes = config('cake_ar.pricing.cache_minutes');
        } catch (Throwable $e) {
            Log::warning('Jomacake pricing API unavailable, using fallback prices', ['error' => $e->getMessage()]);
            // نعيد المحاولة بعد 5 دقائق بدل ما ننتظر الموقع مع كل زائر
            $table = config('cake_ar.pricing.fallback');
            $minutes = 5;
        }

        Cache::put('cake_ar.pricing', $table, now()->addMinutes($minutes));

        return $table;
    }

    private function fetch(): array
    {
        $api = rtrim(config('cake_ar.pricing.api_url'), '/');
        $client = Http::acceptJson()->timeout(5);

        $sizes = $client->get("{$api}/special-request/sizes")->throw()->json('data');
        $rows = $client->get("{$api}/cakes-pricing")->throw()->json();
        $layerCounts = array_flip(config('cake_ar.pricing.layer_ids')); // layer_id => عدد الطبقات

        $table = [];
        foreach ($sizes as $size) {
            // "6 Inch" => "6"
            if (! preg_match('/^(\d+)/', $size['name'], $m)) {
                continue;
            }
            $layers = collect($rows)
                ->where('type', 'layer')
                ->where('size_id', (string) $size['id'])
                ->filter(fn ($row) => isset($layerCounts[(int) $row['layer_id']]))
                ->mapWithKeys(fn ($row) => [$layerCounts[(int) $row['layer_id']] => (float) $row['price']])
                ->sortKeys()
                ->all();

            $table[$m[1]] = ['base' => (float) $size['price'], 'layers' => $layers];
        }

        if (! $table) {
            throw new \RuntimeException('Empty sizes response');
        }

        return $table;
    }
}

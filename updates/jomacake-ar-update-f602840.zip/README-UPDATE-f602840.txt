تحديث jomacake-ar: من 88aa1de إلى f602840
=========================================

يكمّل على ملف التحديث jomacake-ar-update-88aa1de. انسخ الملفات بنفس مساراتها فوق المشروع.

وش الجديد (طلبات المدير):
1. محادثة الذكاء الاصطناعي "تفكر": لما الزبون يرسل تطلع فقاعة فيها ثلاث نقاط تتحرك،
   وكل رد ينتظر ثانية ونص على الأقل (الكعكة الخاصة وصفحة المنتج).
   الملفات: resources/views/special-order.blade.php و resources/views/shop/show.blade.php
2. انميشن تحضير الكيكة وقت "جاري التوليد" بدل الساعة الرملية (Lottie: كيكة دور واحد وتتزين فنتج).
   - ملف جديد: resources/views/partials/cake-loader.blade.php
   - ملف الانميشن: resources/animations/cake-loader.json (ينقرى داخل الصفحة، ما يحتاج مجلد في public)
   - مكتبة lottie-web من cdnjs، ولو ما تحمّلت يطلع رسم بديل.
3. حد الذكاء الاصطناعي صار الضعف: 10 صور و60 رسالة لكل زبون (config/special_order.php و config/shop.php).
   لو عندك المتغيرات في .env غيّرها:
     SPECIAL_ORDER_AI_LIMIT=10
     SPECIAL_ORDER_CHAT_LIMIT=60
     SHOP_AI_LIMIT=10
     SHOP_CHAT_LIMIT=60

ملاحظة: لو صفحتك فيها تعديلات خاصة فيك على special-order.blade.php أو shop/show.blade.php،
قارن قبل ما تستبدل (أو استخدم ملف الـ patch).

ما فيه تغيير في routes/web.php ولا صور جديدة.

بعد النسخ:
php artisan view:clear
php artisan config:clear
